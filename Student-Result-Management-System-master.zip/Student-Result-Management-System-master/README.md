# Exam RESULTS Portal
 Exam Results

Exam results portal for both students and professors .


## Demo content
Link: https://novel-cures.000webhostapp.com/  <br/>
Website is under construction. <br/>
- Admin Login: admin | Password: 123 <br/>
- For Students: First Year | Roll No: 1011<br/>
- For Students: Second Year | Roll No: 2021<br/>


## Technology Used

- Front end: HTML, CSS, JavaScript <br/>
- Back end: PHP, MySQL  <br/>
- Server: XAMPP Server

## Admin Features

- Admin Dashboard <br/>
- Admin can add/update/ Class <br/>
- Admin can add/update/ Subjects  <br/>
- Admin can add/update/ Active/Inactive Subject combination with class  <br/>
- Admin can register new student and also edit info of the student  <br/>
- Aadmin can declare/ edit  result of a student  <br/>
- Admin can change own password.

## Student Features

- Student can search their result using valid rollid <br/>
- Student can download the result in the PDF format.


 

 

 

 


 

